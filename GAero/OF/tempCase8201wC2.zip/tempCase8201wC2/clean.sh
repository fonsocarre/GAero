#!/bin/sh
rm -rf processor*
rm -rf post*
rm -rf foam.log*
rm -rf 0
rm -rf *00
